<?php

interface PHPUnit_Framework_SelfDescribing
{
    public function toString();
}
