
package com.ufqi.gwa2;


public class HelloWorld {

    public HelloWorld(){
        
    }

}
