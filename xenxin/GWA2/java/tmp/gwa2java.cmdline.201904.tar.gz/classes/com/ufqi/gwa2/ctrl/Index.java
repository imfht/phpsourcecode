
package com.ufqi.gwa2.ctrl;

import java.util.HashMap;

import com.ufqi.gwa2.inc.*;

public class Index {

    public Index(){
    
    }

}

